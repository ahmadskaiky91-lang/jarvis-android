# JARVIS Android — source project

This is a starter Android project, not a prebuilt APK. It includes a futuristic interface, Android text-to-speech with a lower pitch, and a foreground listener that attempts to detect “Hey Jarvis” using Android's speech-recognition service.

## Important limitations (read before installing)
- **No APK is included.** Use the GitHub Actions workflow below to build one.
- This is a prototype, not a production-grade wake-word engine. It uses Android `SpeechRecognizer` rather than a dedicated offline wake-word model. `EXTRA_PREFER_OFFLINE` is only a preference; the recognition provider may still require internet and may not support continuous recognition.
- Android/Samsung may stop microphone services or require the app to remain visible. Start listening while the app is open and keep its persistent notification visible.
- The app does **not** contain a general-purpose AI model/API. It can tell the time, open Google Search for questions, and speak a short fallback. Search results are not the same as direct AI answers.
- Pitch is adjusted lower, but the exact voice depends on the text-to-speech voices installed on the phone. This does not clone any actor's voice.
- Review source code before installing any APK built by a third party.

## Build from an Android phone (no computer)
1. Open https://github.com/new in your browser and create a repository named `jarvis-android`. Public is easiest for a first attempt; do not add a README or license.
2. Download this source ZIP and extract it using a file manager or an archive app.
3. Upload the extracted files and folders to the new repository. GitHub mobile upload may be awkward; if it cannot upload folders, use a browser-based Git client or a cloud development environment. Do not upload the ZIP as the only repository file.
4. Open the repository's **Actions** tab and allow workflows if prompted.
5. Run **Build JARVIS APK** using **Run workflow**, or push files to `main` to trigger a build.
6. Open the completed workflow run, find **Artifacts**, and download `jarvis-debug-apk`. Extract the downloaded ZIP to get `app-debug.apk`.
7. Tap the APK and allow “Install unknown apps” for the browser/file manager only if Android asks. Install only the APK you built yourself.
8. Open JARVIS, grant microphone permission, and tap **ACTIVATE HEY JARVIS LISTENER**. Test with the screen on first.

## If GitHub Actions fails
Open the build log and share a screenshot of the first red error. This source project has not been compiled or device-tested in this environment.

## Free features
- Android built-in speech and TTS (device/provider dependent)
- Lower-pitched spoken replies
- “Hey Jarvis” phrase detection attempt
- Time answer
- Google web search handoff

## Not included yet
- Dedicated openWakeWord model/runtime
- Guaranteed fully offline recognition
- A built-in LLM or free general AI answer API
- Guaranteed screen-off wake-word listening
