package com.example.jarvis;

import android.content.Context;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import java.util.Locale;

public class TextToSpeechHelper implements TextToSpeech.OnInitListener {
    private TextToSpeech tts;
    TextToSpeechHelper(Context c) { tts = new TextToSpeech(c, this); }
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            tts.setLanguage(Locale.US);
            tts.setPitch(0.72f);
            tts.setSpeechRate(0.86f);
            try {
                for (Voice v : tts.getVoices()) {
                    if (v.getLocale().equals(Locale.US) && !v.isNetworkConnectionRequired()) { tts.setVoice(v); break; }
                }
            } catch (Exception ignored) {}
        }
    }
    public void say(String text) {
        if (tts != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis-service");
    }
    void close() { if (tts != null) { tts.stop(); tts.shutdown(); } }
}
