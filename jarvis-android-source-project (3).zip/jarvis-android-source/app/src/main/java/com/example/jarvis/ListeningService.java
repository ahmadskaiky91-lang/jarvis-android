package com.example.jarvis;

import android.app.*;
import android.content.*;
import android.os.*;
import android.speech.*;
import java.util.*;

public class ListeningService extends Service {
    private SpeechRecognizer recognizer;
    private Intent speechIntent;
    private boolean waitingForCommand = false;
    private boolean stopped = false;
    private Handler handler = new Handler(Looper.getMainLooper());
    private TextToSpeechHelper speaker;

    @Override public void onCreate() {
        super.onCreate();
        speaker = new TextToSpeechHelper(this);
        createChannel();
        Notification n = new Notification.Builder(this, "jarvis")
            .setContentTitle("JARVIS is listening")
            .setContentText("Say “Hey Jarvis” to begin. Keep expectations modest: Android speech recognition may use online services.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true).build();
        startForeground(17, n);
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speaker.say("Speech recognition is not available on this device.");
            stopSelf(); return;
        }
        speechIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.US.toLanguageTag());
        speechIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        speechIntent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
        speechIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        beginListening();
    }
    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel("jarvis", "JARVIS listener", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }
    private void beginListening() {
        if (stopped) return;
        try {
            if (recognizer != null) { recognizer.destroy(); }
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener() {
                public void onReadyForSpeech(Bundle b) {}
                public void onBeginningOfSpeech() {}
                public void onRmsChanged(float r) {}
                public void onBufferReceived(byte[] b) {}
                public void onEndOfSpeech() {}
                public void onError(int e) { handler.postDelayed(() -> beginListening(), 900); }
                public void onResults(Bundle b) {
                    ArrayList<String> list = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (list != null && !list.isEmpty()) handleText(list.get(0));
                    handler.postDelayed(() -> beginListening(), 700);
                }
                public void onPartialResults(Bundle b) {
                    ArrayList<String> list = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (list != null && !list.isEmpty()) {
                        String s = list.get(0).toLowerCase(Locale.ROOT);
                        if (!waitingForCommand && (s.contains("hey jarvis") || s.contains("okay jarvis") || s.contains("hey jaws"))) {
                            waitingForCommand = true;
                            speaker.say("What can I help you with, sir?");
                        }
                    }
                }
                public void onEvent(int t, Bundle b) {}
            });
            recognizer.startListening(speechIntent);
        } catch (Exception ex) { handler.postDelayed(() -> beginListening(), 1500); }
    }
    private void handleText(String raw) {
        String s = raw.toLowerCase(Locale.ROOT).trim();
        if (!waitingForCommand && (s.contains("hey jarvis") || s.contains("okay jarvis") || s.contains("hey jaws"))) {
            waitingForCommand = true;
            speaker.say("What can I help you with, sir?");
            return;
        }
        if (waitingForCommand) {
            waitingForCommand = false;
            if (s.contains("time")) {
                String answer = "The time is " + java.text.DateFormat.getTimeInstance(java.text.DateFormat.SHORT).format(new Date());
                speaker.say(answer);
            } else if (s.contains("open google") || s.contains("search") || s.contains("who is") || s.contains("what is") || s.contains("how do")) {
                try {
                    String q = raw.replaceAll("(?i)^(hey jarvis[, ]*)", "").trim();
                    Intent web = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com/search?q=" + java.net.URLEncoder.encode(q, "UTF-8")));
                    web.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(web);
                    speaker.say("I have opened a web search for you, sir.");
                } catch (Exception e) { speaker.say("I could not open the search, sir."); }
            } else if (s.contains("stop listening")) {
                speaker.say("Understood, sir. Please stop me from the app.");
                stopSelf();
            } else {
                speaker.say("I can tell the time or search the web for that question. A full AI answer needs an AI service or a local model.");
            }
        }
    }
    @Override public int onStartCommand(Intent i, int flags, int id) { return START_STICKY; }
    @Override public void onDestroy() { stopped = true; if (recognizer != null) recognizer.destroy(); if (speaker != null) speaker.close(); super.onDestroy(); }
    @Override public android.os.IBinder onBind(Intent i) { return null; }
}
