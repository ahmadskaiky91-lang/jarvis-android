package com.example.jarvis;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Locale;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {
    private TextToSpeech tts;
    private TextView status;
    private Button listenButton;
    private boolean listening = false;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFF06101B);
        getWindow().setNavigationBarColor(0xFF06101B);
        tts = new TextToSpeech(this, this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(28, 36, 28, 36);
        root.setBackgroundColor(0xFF06101B);

        TextView logo = new TextView(this);
        logo.setText("J.A.R.V.I.S.");
        logo.setTextColor(0xFF45D9FF);
        logo.setTextSize(34);
        logo.setGravity(Gravity.CENTER);
        root.addView(logo, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("PERSONAL VOICE ASSISTANT");
        subtitle.setTextColor(0xFFB8DCE8);
        subtitle.setTextSize(12);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle);

        status = new TextView(this);
        status.setText("SYSTEM STANDBY");
        status.setTextColor(0xFFFFFFFF);
        status.setTextSize(18);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, 48, 0, 48);
        root.addView(status);

        listenButton = new Button(this);
        listenButton.setText("ACTIVATE HEY JARVIS LISTENER");
        root.addView(listenButton, new LinearLayout.LayoutParams(-1, -2));
        listenButton.setOnClickListener(v -> toggleListening());

        Button voice = new Button(this);
        voice.setText("TEST VOICE");
        root.addView(voice);
        voice.setOnClickListener(v -> say("Good evening, sir. JARVIS is online. How may I assist you?"));

        TextView note = new TextView(this);
        note.setText("\nFree built-in Android speech and voice. For general AI answers, use the web search fallback or connect a compatible AI service in a future version. Keep this app open while testing.");
        note.setTextColor(0xFFB8DCE8);
        note.setTextSize(13);
        note.setGravity(Gravity.CENTER);
        root.addView(note);
        setContentView(root);
        askPermissions();
    }

    private void askPermissions() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 4);
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 5);
        }
    }

    private void toggleListening() {
        if (!hasMic()) { askPermissions(); return; }
        if (!listening) {
            Intent i = new Intent(this, ListeningService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            listening = true;
            listenButton.setText("STOP LISTENER");
            status.setText("LISTENER STARTING — KEEP APP OPEN");
            say("JARVIS is online, sir.");
        } else {
            stopService(new Intent(this, ListeningService.class));
            listening = false;
            listenButton.setText("ACTIVATE HEY JARVIS LISTENER");
            status.setText("SYSTEM STANDBY");
            say("Listener disabled.");
        }
    }
    private boolean hasMic() { return Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED; }
    private void say(String s) { if (tts != null) tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "jarvis"); }
    @Override public void onInit(int result) {
        if (result == TextToSpeech.SUCCESS && tts != null) {
            tts.setLanguage(Locale.US);
            for (android.speech.tts.Voice v : tts.getVoices()) {
                if (v.getLocale().equals(Locale.US) && !v.isNetworkConnectionRequired()) { tts.setVoice(v); break; }
            }
            tts.setPitch(0.78f);
            tts.setSpeechRate(0.88f);
        }
    }
    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r,p,g);
        if (r == 4 && g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) Toast.makeText(this,"Microphone permission granted",Toast.LENGTH_SHORT).show();
    }
    @Override protected void onDestroy() { if (tts != null) { tts.stop(); tts.shutdown(); } super.onDestroy(); }
}
